clear all

u = cmu.unit.units;

a = 5*u.cm

a.as(u.cm)