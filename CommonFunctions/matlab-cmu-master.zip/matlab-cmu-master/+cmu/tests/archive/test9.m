clear all
clc
u = cmu.unit.units;

a = [1 2 4 2]*u.nm;

max(a)

[y,i] = max(a)

b = 5*u.coul;
sqrt(b)

c = [1 2 3]*u.m
sqrt(c)


